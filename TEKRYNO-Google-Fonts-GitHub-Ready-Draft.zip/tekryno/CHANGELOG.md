# Changelog

## 1.003 — 2026-11-26
- Standardized font-menu naming as **Tekryno** for Google Fonts preparation
- Preserved final glyph outlines, advance widths, positioning, and accent alignment
- Added canonical OFL metadata and an editable UFO source
- Prepared specimen and Google Fonts project structure

This is a release candidate. Final Google Fonts QA and licensing confirmation remain pending.
