#!/usr/bin/env python3
"""Build Tekryno TrueType from the editable UFO master. Requires fonttools.

The supplied distributed release TTF is the approved visual master; do a full
font regression/proofing check before replacing it with the built file.
"""
from pathlib import Path
from types import SimpleNamespace
from fontTools.fontBuilder import FontBuilder
from fontTools.ufoLib import UFOReader
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.pointPen import PointToSegmentPen
from fontTools.feaLib.builder import addOpenTypeFeaturesFromString
from fontTools.ttLib import newTable
from fontTools.otlLib.builder import buildStatTable
from fontTools.ttLib import TTFont

ROOT=Path(__file__).resolve().parent
ufo=UFOReader(str(ROOT/'Tekryno-Regular.ufo'))
source=ufo.getGlyphSet()
info=SimpleNamespace(); ufo.readInfo(info)
order=ufo.readLib()['public.glyphOrder']
upm=info.unitsPerEm
cmap={}; glyphs={}; metrics={}
for name in order:
    obj=SimpleNamespace(); pen=TTGlyphPen(source)
    source.readGlyph(name,obj,PointToSegmentPen(pen))
    glyphs[name]=pen.glyph()
    boundsPen=BoundsPen(source)
    source.readGlyph(name,SimpleNamespace(),PointToSegmentPen(boundsPen))
    metrics[name]=(getattr(obj,"width",0),int(round(boundsPen.bounds[0])) if boundsPen.bounds else 0)
    for cp in getattr(obj,'unicodes',[]): cmap[cp]=name
fb=FontBuilder(upm,isTTF=True)
fb.setupGlyphOrder(order)
fb.setupCharacterMap(cmap)
fb.setupGlyf(glyphs)
fb.setupHorizontalMetrics(metrics)
fb.setupHorizontalHeader(ascent=info.ascender,descent=info.descender,lineGap=0)
fb.setupNameTable({'familyName':'Tekryno','styleName':'Regular','uniqueFontIdentifier':'Tekryno Regular;1.003;Shrawan Gaikwad','fullName':'Tekryno Regular','psName':'Tekryno-Regular','version':'Version 1.003','copyright':'Copyright 2026 The Tekryno Project Authors (https://github.com/sgproductionindia/tekryno)','designer':'Shrawan Gaikwad'})
fb.setupOS2(version=4,sTypoAscender=info.ascender,sTypoDescender=info.descender,sTypoLineGap=0,usWinAscent=1220,usWinDescent=260,usWeightClass=400,usWidthClass=5,fsSelection=(1<<6)|(1<<7)|(1<<8),ulCodePageRange1=1,sxHeight=info.xHeight,sCapHeight=info.capHeight)
fb.setupPost(italicAngle=0,underlinePosition=-75,underlineThickness=50)
fb.setupMaxp()
f=fb.font
fea=(ROOT/'features.fea').read_text()
addOpenTypeFeaturesFromString(f,fea)
gasp=newTable('gasp');gasp.gaspRange={65535:15};f['gasp']=gasp
meta=newTable('meta');meta.data={'dlng':'Latn','slng':'Latn'};f['meta']=meta
try:
    buildStatTable(f,[dict(tag='ital',name='Italic',values=[dict(value=0,name='Roman',flags=2)])])
except Exception as e: print('STAT builder warning:',e)
name=f['name'];name.setName('This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: https://openfontlicense.org',13,3,1,0x409);name.setName('https://openfontlicense.org',14,3,1,0x409)
f['head'].fontRevision=1.003
out=ROOT.parent.parent/'build'/'Tekryno-Regular.ttf';out.parent.mkdir(parents=True,exist_ok=True)
f.save(out)
print('Built:',out)
