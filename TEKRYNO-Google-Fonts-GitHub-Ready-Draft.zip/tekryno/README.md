# Tekryno

**Tekryno** is a geometric, angular display typeface designed by **Shrawan Gaikwad**, originally inspired by electronic music production and modular lettering. Its characters deliberately use uppercase-style forms for uppercase and lowercase input.

> **Status:** Google Fonts preparation draft. This repository has not yet been submitted to or accepted by Google Fonts. Final name clearance, source round-trip QA, and Google's onboarding review remain outstanding.

## Font files

- `fonts/Tekryno-Regular.ttf` — TrueType release candidate (for Google Fonts validation)
- `fonts/Tekryno-Regular.otf` — CFF OpenType desktop counterpart
- `documentation/specimen/Tekryno-Type-Specimen.pdf` — five-page vector specimen

**Typeface menu name:** Tekryno (Regular). The uppercase **TEKRYNO** styling in artwork is branding, not the internal family name.

## Source

The editable source is `sources/Tekryno-Regular.ufo` (UFO v3), with original Illustrator SVG character designs archived in `sources/original-svg-archive/`. Open the UFO in a compatible font editor. The source build helper `sources/build_from_ufo.py` is provided for ongoing development. The historical SVG builder is retained for provenance; it predates later accent alignment and QA corrections.

The original release candidate should be visually compared with any font regenerated from editable sources before publication. The build helper is a development baseline, not a certified bit-for-bit reproduction of the approved TTF.

## Credits

Design and original artwork: **Shrawan Gaikwad**. Copyright 2026 The Tekryno Project Authors (https://github.com/sgproductionindia/tekryno).

## License

This project is **prepared** for release under the **SIL Open Font License, Version 1.1**, pending the copyright holder's final agreement before publication. See `OFL.txt` and `AUTHORS.txt`. No Reserved Font Name is declared.

## Submission to Google Fonts

After the project is public and licensed, run the Google Fonts profile in Fontspector, review actual failures, confirm Latin Core shaping and editable-source reproducibility, and follow current Google Fonts onboarding guidelines. See `documentation/SUBMISSION-CHECKLIST.md`.

