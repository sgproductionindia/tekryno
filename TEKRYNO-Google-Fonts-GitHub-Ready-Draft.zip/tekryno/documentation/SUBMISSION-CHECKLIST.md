# Tekryno — submission checklist

Proposed upstream repo: https://github.com/sgproductionindia/tekryno (NOT YET CREATED as of package preparation)

- [ ] Confirm permission to release **all Tekryno styles and sources under OFL 1.1**. This is a permanent open license grant for recipients who comply with it.
- [ ] Clear the *Tekryno* typeface name for relevant markets; a preliminary catalog search is not a legal trademark opinion.
- [ ] Create repository `sgproductionindia/tekryno` as **Public** and publish the source, docs, license and font files.
- [ ] Verify the LICENSE copyright author(s) are correct and complete. Assess employment/commission agreements if relevant.
- [ ] Check internal name IDs and OTF CFF names match **Tekryno**, with TTF named **Tekryno-Regular.ttf**.
- [ ] Check source UFO can rebuild a release-quality TTF; compare glyph bounds, kerning, mark placement, codepoints, and line metrics.
- [ ] Re-run full official Fontspector Google Fonts profile; resolve actual FAIL results and review WARN results.
- [ ] Verify all required Latin Core glyphs *and* text shaping behavior in a browser and desktop apps.
- [ ] Complete upstream README, author credits, licensing and requested sample images.
- [ ] Submit according to Google's **current** Add Font intake and upstream contribution process (do not open the final submission until checks pass).

References:
- https://googlefonts.github.io/gf-guide/onboarding.html
- https://googlefonts.github.io/gf-guide/upstream.html
- https://googlefonts.github.io/gf-guide/requirements.html
- https://googlefonts.github.io/gf-guide/license-file
- https://github.com/googlefonts/googlefonts-project-template
