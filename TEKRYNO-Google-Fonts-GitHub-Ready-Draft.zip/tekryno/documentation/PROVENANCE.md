# Source provenance

Original design: individual Illustrator SVG outlines provided by the designer. The 63 Latin-extended SVGs and the legacy SVG sources are preserved unmodified here. They are dated earlier than the approved final accent-aligned glyphs. The final editable UFO is exported from the approved TEKRYNO TTF release candidate, so its outlines incorporate the later geometry, diacritic alignment, and QA fixes.

The historical SVG builder is provided for reference only: it does not by itself regenerate the fully corrected final release. Never replace the final released font with the historical output without visual and technical verification.
